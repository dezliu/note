package com.liudezhi.test;

import com.liudezhi.dao.UserDao;
import com.liudezhi.dao.impl.UserDaoImpl;
import com.liudezhi.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * 测试mybatis的crud 操作
 */
public class MybatisTest {

    private InputStream in;
    private UserDao userDao;

    @Before //用于在测试方法执行之前执行
    public void init() throws Exception {
        //1. 读取配置文件，生成字节输入流
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2. 获取SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);
        //3. 使用工厂对象，创建dao对象
        //4. 获取dao 的代理对象
        userDao = new UserDaoImpl(factory);
    }

    @After  //用于在测试方法执行之后执行
    public void destory() throws IOException {
        in.close();
    }

    @Test
    public void testFindAll() {
        //执行查询所有方法
        List<User> users = userDao.findAll();
        for (User user: users) {
            System.out.println(user);
        }
    }

    /**
     * 测试保存操作
     */
    @Test
    public void testSave() {
        User user = new User();
        user.setUsername("老婆");
        user.setAddress("安徽省马鞍山市和县");
        user.setSex("女");
        user.setBirthday(new Date());

        //执行保存方法
        userDao.saveUser(user);
    }

    /**
     * 测试更新用户信息
     */
    @Test
    public void testUpdate() {
        User user = new User();
        user.setUsername("xs");
        user.setAddress("马鞍山和县");
        user.setSex("女");
        user.setId(50);
        user.setBirthday(new Date());

        userDao.updateUser(user);
    }

    /**
     * 测试删除
     */
    @Test
    public void testDelete() {
        userDao.deleteUser(48);
    }

    /**
     * 测试查询用户信息
     */
    @Test
    public void testFindById() {
        System.out.println(userDao.findById(50));
    }

    /**
     * 测试根据姓名查询用户
     */
    @Test
    public void testFindByName() {
        List<User> users = userDao.findByName("%x%");
//        List<User> users = userDao.findByName("x");
        for (User user: users) {
            System.out.println(user);
        }
    }

    /**
     * 测试查询总用户数
     */
    @Test
    public void testFindTotal() {
        int count = userDao.findTotal();
        System.out.println(count);
    }
}
