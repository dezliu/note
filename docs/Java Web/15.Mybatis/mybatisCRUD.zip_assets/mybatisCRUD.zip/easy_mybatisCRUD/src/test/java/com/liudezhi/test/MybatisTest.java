package com.liudezhi.test;

import com.liudezhi.dao.UserDao;
import com.liudezhi.domain.QueryVo;
import com.liudezhi.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * 测试mybatis的crud 操作
 */
public class MybatisTest {

    private InputStream in;
    private SqlSession sqlSession;
    private UserDao userDao;

    @Before //用于在测试方法执行之前执行
    public void init() throws Exception {
        //1. 读取配置文件，生成字节输入流
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2. 获取SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);
        //3. 获取SqlSession对象
        sqlSession = factory.openSession();
        //4. 获取dao 的代理对象
        userDao = sqlSession.getMapper(UserDao.class);
    }

    @After  //用于在测试方法执行之后执行
    public void destory() throws IOException {
        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
        in.close();
    }

    @Test
    public void testFindAll() {
        //执行查询所有方法
        List<User> users = userDao.findAll();
        for (User user: users) {
            System.out.println(user);
        }
    }

    /**
     * 测试保存操作
     */
    @Test
    public void testSave() {
        User user = new User();
        user.setUsername("mybatis");
        user.setAddress("上海市松江区");
        user.setSex("男");
        user.setBirthday(new Date());

        //执行保存方法
        userDao.saveUser(user);
    }

    /**
     * 测试更新用户信息
     */
    @Test
    public void testUpdate() {
        User user = new User();
        user.setUsername("xs");
        user.setAddress("马鞍山和县");
        user.setSex("女");
        user.setId(50);
        user.setBirthday(new Date());

        userDao.updateUser(user);
    }

    /**
     * 测试删除
     */
    @Test
    public void testDelete() {
        userDao.deleteUser(48);
    }

    /**
     * 测试查询用户信息
     */
    @Test
    public void testFindById() {
        System.out.println(userDao.findById(50));
    }

    /**
     * 测试根据姓名查询用户
     */
    @Test
    public void testFindByName() {
        List<User> users = userDao.findByName("%x%");
//        List<User> users = userDao.findByName("x");
        for (User user: users) {
            System.out.println(user);
        }
    }

    /**
     * 测试查询总用户数
     */
    @Test
    public void testFindTotal() {
        int count = userDao.findTotal();
        System.out.println(count);
    }

    /**
     * 测试使用QueryVo 作为查询条件
     */
    @Test
    public void testFindByVo() {
        QueryVo vo = new QueryVo();
        User user = new User();
        user.setUsername("%王%");
        vo.setUser(user);
        List<User> users = userDao.findUserByVo(vo);
        for(User u : users) {
            System.out.println(u);
        }
    }
}
