package com.liudezhi.mybatis.sqlsession;

import com.liudezhi.mybatis.cfg.Configuration;
import com.liudezhi.mybatis.sqlsession.defaults.DefaultSqlSessionFactory;
import com.liudezhi.mybatis.util.XMLConfigBuilder;

import java.io.InputStream;

/**
 * 用于创建一个SqlSessionFactory 对象
 */
public class SqlSessionFactoryBuilder {
    /**
     * 根据参数的字节输入流来构建一个SqlSessionFactory 工厂
     * @param config
     * @return
     */
    public SqlSessionFactory build(InputStream config) {
        Configuration cfg = XMLConfigBuilder.loadConfiguration(config);
        return new DefaultSqlSessionFactory(cfg);
    }
}
