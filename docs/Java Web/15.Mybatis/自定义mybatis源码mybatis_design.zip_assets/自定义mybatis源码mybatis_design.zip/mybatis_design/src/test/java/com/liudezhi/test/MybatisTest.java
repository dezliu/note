package com.liudezhi.test;

import com.liudezhi.dao.UserDao;
import com.liudezhi.domain.User;
import com.liudezhi.mybatis.io.Resources;
import com.liudezhi.mybatis.sqlsession.SqlSession;
import com.liudezhi.mybatis.sqlsession.SqlSessionFactory;
import com.liudezhi.mybatis.sqlsession.SqlSessionFactoryBuilder;

import java.io.InputStream;
import java.util.List;

public class MybatisTest {

    public static void main(String[] args) throws Exception {
        //1. 读取配置文件
        InputStream in = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2. 创建SqlSessionFactory 工厂
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        //3. 使用工厂生产SqlSession 对象
        SqlSession session = factory.openSession();
        //4. 使用SqlSession 创建Dao 接口的代理对象
        UserDao userDao = session.getMapper(UserDao.class);
        //5. 使用代理对象执行方法
        List<User> users = userDao.findAll();
        for (User user: users) {
            System.out.println(user);
        }
        //6. 释放资源
        session.close();
        in.close();
    }
}
